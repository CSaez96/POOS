import requests
from datetime import datetime
import hashlib
from conexion_bd import get_connection
from modelos.Simulacion import Simulacion
from mysql.connector import Error

class SimulacionOperaciones:
	@staticmethod
	def obtener_valor_dolar(fecha):
		try:
			fecha_str = fecha.strftime("%d-%m-%Y")
			# Definimos la URL a la cual nos conectaremos para efectuar una solicitud ("request")
			url = f"https://mindicador.cl/api/dolar/{fecha_str}"
			# Ejecutamos una solicitud GET al servidor y almacenamos la respuesta en "response" ("respuesta" en español)
			response = requests.get(url)
			# Si el servicio nos entrega el código HTTP 200 ("OK")...
			if response.status_code == 200:
				# ...transformamos el string de la respuesta a formato JSON...
				data = response.json()
				# ...y obtenemos el valor del dólar, retornándolo:
				return data['serie'][0]['valor']
			else:
				raise Exception("Error al obtener valor del dólar")
		except Exception as e:
			print(f"Error al consultar API: {e}")
			return None

	@staticmethod
	def crear_simulacion(simulacion):
		connection = get_connection()
		if connection is None:
			return False
		try:
			cursor = connection.cursor()
			
			sql = """INSERT INTO simulaciones (unidades, costo_unitario_usd, costo_envio_usd, nombre_articulo, codigo_articulo, nombre_proveedor, costo_total_clp, valor_dolar_clp, fecha_simulacion, id_usuario)
					 VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
			valores = (simulacion.unidades, simulacion.costo_unitario_usd, simulacion.costo_envio_usd, simulacion.nombre_articulo, simulacion.codigo_articulo, simulacion.nombre_proveedor, simulacion.costo_total_clp, simulacion.valor_dolar_clp, simulacion.fecha_simulacion, simulacion.id_usuario)
			
			cursor.execute(sql, valores)
			connection.commit()
			return True
		except Error as e:
			print(f"Error al crear simulacion: {e}")
			return False
		finally:
			if connection.is_connected():
				cursor.close()
				connection.close()

	@staticmethod
	def listar_simulaciones():
		connection = get_connection()
		simulaciones = []
		
		try:
			cursor = connection.cursor(dictionary=True)
			cursor.execute("SELECT * FROM simulaciones ORDER BY fecha_simulacion DESC")
			for row in cursor.fetchall():
				simulacion = Simulacion(**row)
				simulaciones.append(simulacion)
			return simulaciones
		except Error as e:
			print(f"Error al listar simulaciones: {e}")
			return []
		finally:
			if connection.is_connected():
				cursor.close()
				connection.close()