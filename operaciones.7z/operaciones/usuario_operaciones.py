import hashlib
from conexion_bd import get_connection
from modelos.Usuario import Usuario
from mysql.connector import Error

class UsuarioOperaciones:
	@staticmethod
	def crear_usuario(usuario):
		connection = get_connection()
		if connection is None:
			return False
		try:
			cursor = connection.cursor()

			sql = """INSERT INTO usuarios 
			(username, password_hash) 
			VALUES (%s, %s)"""
			valores = (usuario.username, usuario.password_hash)
			cursor.execute(sql, valores)
			connection.commit()
			return True
		except Error as e:
			print(f"Error al crear usuario: {e}")
			return False
		finally:
			if connection.is_connected():
				cursor.close()
				connection.close()

	@staticmethod
	def buscar_por_username(username):
		connection = get_connection()
		try:
			cursor = connection.cursor(dictionary=True)
			cursor.execute("SELECT * FROM usuarios WHERE username = %s", (username,))
			result = cursor.fetchone()
			if result:
				return Usuario(**result)
			return None
		except Error as e:
			print(f"Error al buscar usuario: {e}")
			return None
		finally:
			if connection.is_connected():
				cursor.close()
				connection.close()

	@staticmethod
	def listar_usuarios():
		connection = get_connection()
		usuarios = []

		try:
			cursor = connection.cursor(dictionary=True)
			cursor.execute("SELECT * FROM usuarios")
			for row in cursor.fetchall():
				usuario = Usuario(**row)
				usuarios.append(usuario)
			return usuarios
		except Error as e:
			print(f"Error al listar multas: {e}")
		finally:
			if connection.is_connected():
				cursor.close()
				connection.close()

	@staticmethod
	def eliminar_usuario(id):
		connection = get_connection()
		if connection is None:
			return False
		try:
			cursor = connection.cursor()
			cursor.execute("""DELETE FROM usuarios WHERE id = %s""", (id,))
			connection.commit()
			return True
		except Error as e:
			print(f"Error al eliminar usuario: {e}")
			return False
		finally:
			if connection.is_connected():
				cursor.close()
				connection.close()

	@staticmethod
	def buscar_por_id(id):
		connection = get_connection()
		try:
			cursor = connection.cursor(dictionary=True)
			cursor.execute("SELECT * FROM usuarios WHERE id = %s", (id,))
			result = cursor.fetchone()
			if result:
				return Usuario(**result)
			return None
		except Error as e:
			print(f"Error al buscar usuario: {e}")
			return None
		finally:
			if connection.is_connected():
				cursor.close()
				connection.close()

	@staticmethod
	def actualizar_usuario(usuario_nuevo):
		connection = get_connection()
		if connection is None:
			return False
		try:
			cursor = connection.cursor()
			sql = """UPDATE usuarios 
			SET 
			username = %s,
			password_hash = %s
			WHERE id = %s"""
			valores = (usuario_nuevo.username, usuario_nuevo.password_hash, usuario_nuevo.id)
			cursor.execute(sql, valores)
			connection.commit()
			return True
		except Error as e:
			print(f"Error al actualizar usuario: {e}")
			return False
		finally:
			if connection.is_connected():
				cursor.close()
				connection.close()